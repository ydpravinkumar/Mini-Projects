public class Ingredients {

    String name;
    int ingquantity;



    public  Ingredients(String ingname,int ingquantity)
    {
        this.name = ingname;
        this.ingquantity = ingquantity;
    }

}
