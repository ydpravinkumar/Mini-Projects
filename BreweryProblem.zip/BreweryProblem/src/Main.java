import java.util.Locale;
import java.util.Scanner;

public class Main {


    public static void main(String[] args) {

        /**
         * Initiliazing Controller Object and calling the menuController to start the program
         */
        Controller controller = new Controller();
        controller.menuController();


    }
}